# LifeLink — Project Log

Running log of the AB Talks 60-Day Claude AI Challenge capstone. One entry per day.

---

## Day 1 — Discovery, Requirements & Planning

**Focus:** Went from no idea to a fully scoped, approved project.

**What happened:**
- Interviewed to discover the project: LifeLink, an AI-powered emergency healthcare coordination platform.
- Scoped v1.0 down from the full multi-sided platform vision to a single primary user (patient/family) with hospitals, blood banks, donors, and ambulances represented as mock data — the right size for 1–2 hrs/day over 10 days.
- Decided the AI feature: urgency triage (Critical/High/Medium/Low) + AI-explained, distance/availability/compatibility-ranked recommendations.
- Locked scope boundaries: what's in v1.0, what's explicitly deferred.
- Chose the technical stack: Next.js + Tailwind + Firebase (Auth + Firestore) + Anthropic Claude API + Vercel — all free-tier.

**Deliverables produced:**
- `LifeLink_PRD.docx` — full Product Requirements Document
- `LifeLink_Implementation_Blueprint.md` — day-by-day build plan for Days 2–10
- `LifeLink_Pitch_Deck.pptx` — 10-slide pitch deck

**Status at end of day:** Fully planned, nothing built yet. Ready for Day 2.

---

## Day 2 — System Design

**Focus:** Turned the approved PRD into a complete, implementation-ready technical design — no code written.

**What happened:**
- Created the GitHub repository (`lifelink`), cloned it locally, and set up the initial folder structure (`app/`, `components/`, `lib/`, `public/`, `design/`, `docs/`).
- Finalized the architecture: full Mermaid component diagram, data-flow diagram, request lifecycle state machine, AI interaction detail, and external services list.
- Finalized the Firestore database design: all 7 collections/subcollections, every field typed and validated against every PRD functional requirement, plus draft Firestore Security Rules.
- Finalized the API design: full specs for the two custom endpoints (`/api/triage`, `/api/match`) including validation, auth, and error handling — and explicitly documented which operations need no custom endpoint at all (direct Firestore SDK calls).
- Designed the complete UI/UX: user flow diagram, screen list (every screen traced to a PRD requirement), low-fidelity wireframes for all 6 screens, and responsive behavior rules.
- Finalized the project folder structure and what will go where, day by day, through Day 10.
- Drafted the two AI prompt templates (triage + recommendation reasoning) that Day 6 and Day 7 will implement directly.
- Drafted the mock data set: 7 hospitals, 4 blood banks, 9 donors with realistic coordinates.
- Swept the Implementation Blueprint for leftover terminology from an earlier draft and corrected it to match the finalized Firestore schema exactly.

**Deliverables produced:**
- `docs/ARCHITECTURE.md`
- `docs/SCHEMA.md`
- `docs/API.md`
- `docs/UI-WIREFRAMES.md`
- `docs/PROJECT-STRUCTURE.md`
- `design/prompts.md`, `design/mock-data.md`, `design/schema.md`, `design/screens.md`, `design/api-contracts.md`
- Blueprint corrections for full Firebase/Firestore consistency

**Status at end of day:** Every implementation decision for the remaining 8 days is made. Day 3 can begin building immediately — no further design decisions expected.

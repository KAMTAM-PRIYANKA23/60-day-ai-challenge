# LifeLink — Mock Data Set (Day 2 draft, seeded into Firestore on Day 3)

**Region chosen:** Hyderabad, Telangana, India — since that's your approximate location and real GPS will be used in the demo, distances will read as genuine and nearby. **If you'll actually demo from a different city, tell me before Day 3 and I'll regenerate these coordinates for that city instead** — everything else about the mock data stays the same.

All coordinates are realistic and spread within ~15km of central Hyderabad (17.3850° N, 78.4867° E).

---

## Hospitals (7)

| name | latitude | longitude | bedsAvailable | specialties |
|---|---|---|---|---|
| City General Hospital | 17.3850 | 78.4867 | 4 | Cardiology, Trauma |
| Lakeside Medical Center | 17.4239 | 78.4738 | 12 | General, Pediatrics |
| Sunrise Multispecialty Hospital | 17.3616 | 78.4747 | 2 | Orthopedics, ICU |
| Continental Care Hospital | 17.4400 | 78.3489 | 8 | Neurology, Cardiology |
| Metro Trauma & Emergency Center | 17.3287 | 78.5502 | 6 | Trauma, Emergency |
| Green Valley Hospital | 17.4646 | 78.5312 | 15 | General, Maternity |
| Rainbow Children's & General Hospital | 17.4126 | 78.4482 | 3 | Pediatrics, General |

## Blood Banks (4)

| name | latitude | longitude | inventory |
|---|---|---|---|
| Central Blood Bank | 17.3900 | 78.4750 | O+:12, O-:3, A+:8, A-:2, B+:10, B-:1, AB+:4, AB-:1 |
| Red Cross Hyderabad Chapter | 17.4062 | 78.4691 | O+:6, O-:0, A+:5, A-:1, B+:7, B-:2, AB+:2, AB-:0 |
| LifeCare Blood Center | 17.3616 | 78.5240 | O+:9, O-:4, A+:3, A-:0, B+:5, B-:1, AB+:1, AB-:2 |
| Community Blood Bank Secunderabad | 17.4399 | 78.4983 | O+:15, O-:2, A+:10, A-:3, B+:12, B-:3, AB+:5, AB-:1 |

## Donors (9)

| name | bloodType | latitude | longitude | isAvailable |
|---|---|---|---|---|
| Arjun Rao | O+ | 17.3925 | 78.4802 | true |
| Priya Nair | A+ | 17.4150 | 78.4600 | true |
| Karthik Reddy | O- | 17.3700 | 78.4900 | true |
| Sneha Iyer | B+ | 17.4300 | 78.5100 | false |
| Farhan Ali | AB+ | 17.3550 | 78.4700 | true |
| Divya Menon | O+ | 17.4500 | 78.4400 | true |
| Rahul Verma | A- | 17.3800 | 78.5300 | true |
| Ananya Das | B- | 17.4050 | 78.4950 | true |
| Vikram Singh | O+ | 17.3300 | 78.4600 | false |

---

## Notes for Day 3 Seeding

- These will be entered directly into Firestore via the Console's data editor (small enough dataset — no seed script needed for v1.0).
- `inventory` on blood banks is a map field, not a subcollection — matches `docs/SCHEMA.md` Section 4.
- Two donors are intentionally `isAvailable: false`, to make sure the filtering logic (PRD FR-11, "available donors only") is actually testable on Day 7.
- Coordinates are spread widely enough (~15km radius) that distance-based ranking will visibly differentiate results depending on where a test request is raised from within Hyderabad.

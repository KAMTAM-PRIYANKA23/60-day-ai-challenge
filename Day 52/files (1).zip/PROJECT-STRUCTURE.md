# LifeLink — Project Structure

**Status:** Approved Day 2 design. This is the folder layout Day 3 will scaffold and Days 4–10 will fill in. No code exists yet — this is the map for where it will go.

---

## 1. Full Target Structure (end state, after Day 10)

```
lifelink/
├── app/
│   ├── layout.js                  # Root layout: fonts, global providers, disclaimer footer
│   ├── page.js                    # Home / Dashboard (redirects to /login if signed out)
│   ├── globals.css                # Tailwind imports + base styles
│   │
│   ├── login/
│   │   └── page.js
│   ├── signup/
│   │   └── page.js
│   ├── profile/
│   │   └── page.js
│   ├── emergency/
│   │   └── page.js                # Raise Emergency form
│   ├── results/
│   │   └── [id]/
│   │       └── page.js            # Results Dashboard (live for new requests, read-only for history)
│   ├── history/
│   │   └── page.js
│   │
│   └── api/
│       ├── triage/
│       │   └── route.js           # POST /api/triage
│       └── match/
│           └── route.js           # POST /api/match
│
├── components/
│   ├── UrgencyBadge.js
│   ├── ResourceCard.js
│   ├── StatusTracker.js
│   ├── ContactForm.js
│   ├── ContactList.js
│   ├── NavBar.js
│   └── Disclaimer.js
│
├── lib/
│   ├── firebaseClient.js          # Firebase app + Auth + Firestore init (client-side)
│   ├── firebaseAdmin.js           # Firebase Admin SDK init (server-side only, used in API routes)
│   ├── anthropicClient.js         # Claude API client (server-side only)
│   ├── geolocation.js             # Geolocation permission + capture helper
│   ├── distance.js                # Haversine formula utility
│   ├── scoring.js                 # Deterministic ranking logic for /api/match
│   └── auth.js                    # Client-side session/auth-check helpers
│
├── design/                        # Day 2 working artifacts (not polished docs)
│   ├── schema.md
│   ├── screens.md
│   ├── api-contracts.md
│   ├── prompts.md
│   └── mock-data.md
│
├── docs/                          # Polished deliverables (this file lives here)
│   ├── ARCHITECTURE.md
│   ├── SCHEMA.md
│   ├── API.md
│   ├── UI-WIREFRAMES.md
│   └── PROJECT-STRUCTURE.md
│
├── public/
│   └── (static assets — icons, favicon, etc., added as needed)
│
├── .env.local                     # Secrets — git-ignored, created Day 3
├── .gitignore
├── next.config.js                 # Created by Next.js scaffolding, Day 3
├── tailwind.config.js             # Created by Tailwind setup, Day 3
├── package.json
└── README.md
```

---

## 2. What Each Top-Level Folder Is Responsible For

### `app/`
The Next.js App Router folder — one subfolder per route, each containing a `page.js`. This is where all screen-level code lives. `app/api/` is the one exception: those `route.js` files are server-only endpoints, never rendered as pages. This maps one-to-one with the Screen List in `UI-WIREFRAMES.md` Section 2.

### `components/`
Reusable UI pieces used across more than one screen (e.g., `ResourceCard` appears on both Results and, indirectly, History). Anything used on exactly one screen stays inline in that screen's `page.js` rather than being extracted here — avoids over-engineering a small app.

### `lib/`
Non-visual logic: API clients, utility functions, and helpers. The Day 2 architectural rule ("browser never talks to Claude directly," per `ARCHITECTURE.md` Section 2) is enforced by folder convention here: `anthropicClient.js` and `firebaseAdmin.js` are only ever imported inside `app/api/*/route.js` files, never inside anything under `app/` that renders client-side.

### `design/`
Raw Day 2 working files — the SQL-equivalent schema notes, screen list, API contract drafts, AI prompt drafts, and mock data list, exactly as referenced in the Blueprint's Day 2 section. These are working notes, kept for traceability, but `docs/` is what other conversations/AI sessions should read first.

### `docs/`
The five polished, reviewed deliverables from today. This is the folder to hand to a fresh AI conversation alongside the Blueprint, per the "How to Use This Blueprint Each Day" instructions.

### `public/`
Static files Next.js serves directly (favicon, any static images). Expected to stay nearly empty for this project — no image-heavy content in v1.0.

---

## 3. Where Future Code Lives, Day by Day

| Day | Adds to |
|---|---|
| 3 | `next.config.js`, `tailwind.config.js`, `lib/firebaseClient.js`, root `app/page.js` (placeholder) |
| 4 | `app/login/`, `app/signup/`, `app/profile/`, `lib/auth.js`, `components/ContactForm.js`, `components/ContactList.js` |
| 5 | `app/emergency/`, `lib/geolocation.js`, `lib/distance.js`, `app/results/[id]/` (shell) |
| 6 | `app/api/triage/route.js`, `lib/anthropicClient.js`, `components/UrgencyBadge.js` |
| 7 | `app/api/match/route.js`, `lib/firebaseAdmin.js`, `lib/scoring.js`, `components/ResourceCard.js` |
| 8 | `app/history/`, `components/StatusTracker.js` |
| 9 | No new files expected — edits only |
| 10 | Final `README.md` |

---

## 4. Why This Structure

- **Matches the App Router's file-based routing exactly** — no ambiguity about where a new screen goes; the URL and the folder path are the same thing.
- **`lib/` cleanly separates client-safe code from server-only code** by filename convention (`firebaseClient` vs `firebaseAdmin`), which directly enforces the "API key never reaches the browser" security rule from `ARCHITECTURE.md` Section 7.
- **`design/` vs `docs/` split** keeps rough Day 2 notes from cluttering the polished deliverables, while preserving them for traceability if a design decision is ever questioned later.
- **Flat and shallow** — no deeply nested feature folders, no premature abstraction (e.g., no `features/`, `modules/`, or `services/` layers). For a solo build at 1–2 hrs/day, a flatter structure is faster to navigate and harder to get lost in.

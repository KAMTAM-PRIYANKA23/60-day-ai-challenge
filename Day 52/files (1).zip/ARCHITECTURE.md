# LifeLink — System Architecture

**Status:** Approved Day 2 design. This is the technical source of truth alongside `SCHEMA.md`, `API.md`, `UI-WIREFRAMES.md`, and `PROJECT-STRUCTURE.md`. Implementation (Days 3–10) must follow this document; any deviation discovered mid-build should be flagged before proceeding, not silently changed.

---

## 1. Locked Tech Stack

| Layer | Choice | Why |
|---|---|---|
| Frontend framework | **Next.js (React, App Router)** | One framework for both UI and server-side API routes; React skills transfer directly |
| Styling | **Tailwind CSS** | Fast, consistent responsive styling without hand-written CSS |
| Backend logic | **Next.js API Routes** (serverless functions) | Keeps the Claude API key server-side only; no separate backend to host |
| Auth | **Firebase Authentication** (email/password) | Free, fully managed, minimal setup, works seamlessly with Firestore |
| Database | **Cloud Firestore** (Firebase, Native mode) | Free tier, real-time-capable NoSQL document store, no server to manage, integrates natively with Firebase Auth |
| AI | **Anthropic Claude API** | Powers urgency triage and recommendation reasoning — the core "AI-powered" feature |
| Location | **Browser Geolocation API** + Haversine formula | Real GPS at zero cost; no paid maps SDK needed since map view is out of scope |
| Hosting | **Vercel** (free tier) | Native Next.js support, Git-based auto-deploy |
| Version control | **GitHub** | Required for Vercel deploys; also the project portfolio artifact |

No paid services anywhere in this stack.

---

## 2. Component Diagram

```mermaid
graph TB
    subgraph Client["Browser (Patient's Device)"]
        UI[Next.js Frontend<br/>React + Tailwind]
        GEO[Browser Geolocation API]
    end

    subgraph Vercel["Vercel — Hosting"]
        PAGES[Next.js Pages<br/>Login / Signup / Profile / Emergency / Results / History]
        API1["/api/triage<br/>(server route)"]
        API2["/api/match<br/>(server route)"]
    end

    subgraph Firebase["Firebase"]
        AUTH[Firebase Authentication]
        FS[(Cloud Firestore<br/>users, requests, hospitals,<br/>bloodBanks, donors)]
    end

    subgraph Anthropic["Anthropic"]
        CLAUDE[Claude API]
    end

    UI -->|renders| PAGES
    UI -->|requests permission| GEO
    GEO -->|lat/long| UI

    UI -->|signup/login/session| AUTH
    UI -->|read/write profile, contacts, requests| FS

    UI -->|POST description| API1
    API1 -->|prompt| CLAUDE
    CLAUDE -->|urgency + rationale| API1
    API1 -->|urgency result| UI

    UI -->|POST description, urgency, location| API2
    API2 -->|read mock data| FS
    API2 -->|prompt with candidates| CLAUDE
    CLAUDE -->|ranked reasoning| API2
    API2 -->|ranked results| UI
    API2 -->|save matches| FS

    style Client fill:#CADCFC,stroke:#1E2761
    style Vercel fill:#F7F8FC,stroke:#1E2761
    style Firebase fill:#FFE8B0,stroke:#B8860B
    style Anthropic fill:#F9C4C4,stroke:#990011
```

**Key design principle:** the browser talks *directly* to Firebase Auth and Firestore for all standard CRUD (profile, contacts, request history) using the Firebase client SDK — there is no custom REST layer for that. Custom Next.js API routes exist **only** for the two AI-powered operations, because those require the Anthropic API key, which must never reach the browser.

---

## 3. Data Flow — Core User Journey

```mermaid
flowchart TD
    A[Patient opens app] --> B{Logged in?}
    B -- No --> C[Signup / Login via Firebase Auth]
    C --> D[Profile created/loaded in Firestore]
    B -- Yes --> D
    D --> E[Patient taps Raise Emergency]
    E --> F[Types description]
    F --> G[Browser requests GPS location]
    G --> H{Permission granted?}
    H -- Yes --> I[lat/long captured]
    H -- No --> J[Manual location text entered]
    I --> K[Request document created in Firestore, status = Submitted]
    J --> K
    K --> L[POST /api/triage: description]
    L --> M[Claude returns urgency + rationale]
    M --> N[Firestore request updated with urgency]
    N --> O[POST /api/match: description, urgency, location]
    O --> P[Server fetches mock hospitals/bloodBanks/donors]
    P --> Q[Haversine distance calculated per resource]
    Q --> R[Deterministic scoring: distance + availability + compatibility + urgency weight]
    R --> S[Top candidates sent to Claude for reasoning text]
    S --> T[Ranked results + reasons returned]
    T --> U[Results saved to requests/matches subcollection]
    U --> V[Results Dashboard renders: urgency badge + ranked cards]
    V --> W[Status simulation begins: Matching to Hospital Notified to Ambulance Dispatched]
    W --> X[Request visible in History]
```

---

## 4. Request Lifecycle — Sequence Diagram

This shows exactly what happens, in order, when a patient submits an emergency request.

```mermaid
sequenceDiagram
    participant P as Patient (Browser)
    participant FA as Firebase Auth
    participant FS as Firestore
    participant T as /api/triage
    participant M as /api/match
    participant AI as Claude API

    P->>FA: Verify session
    FA-->>P: Authenticated (uid)
    P->>P: Capture GPS (or manual location)
    P->>FS: Create requests/{id} (status: Submitted)
    FS-->>P: requestId

    P->>T: POST { description }
    T->>AI: Triage prompt (description)
    AI-->>T: { urgency, rationale }
    T-->>P: { urgency, rationale }
    P->>FS: Update requests/{id} (urgency, rationale)

    P->>M: POST { description, urgency, lat, lng }
    M->>FS: Get hospitals, bloodBanks, donors
    FS-->>M: mock resource documents
    M->>M: Compute distance (Haversine) + score each candidate
    M->>AI: Reasoning prompt (top candidates + urgency)
    AI-->>M: reasons per candidate
    M-->>P: { hospitals[], bloodBanks[], donors[] } ranked + reasoned
    M->>FS: Write requests/{id}/matches/*

    P->>P: Render results dashboard
    P->>P: Begin status simulation (client-side timer)
    P->>FS: Update requests/{id}.status at each stage
```

---

## 5. AI Interaction Detail

LifeLink calls Claude in two distinct, purpose-built ways:

### 5.1 Urgency Triage (`/api/triage`)
- **Input:** the patient's free-text description only
- **Prompt strategy:** instructs Claude to act as a cautious triage assistant, classify into exactly one of `Critical | High | Medium | Low`, err toward higher urgency when uncertain (safety-first), and return strict JSON
- **Output contract:** `{ "urgency": "...", "rationale": "..." }`
- **Failure handling:** if Claude's response fails to parse or returns an invalid urgency value, the server falls back to `"Medium"` and logs the issue — the user never sees a crash

### 5.2 Recommendation Reasoning (`/api/match`)
- **Input:** the top-scored candidates (already ranked deterministically by distance + availability + compatibility), plus the urgency level and description
- **Prompt strategy:** Claude is given each candidate's actual stats (distance, beds/inventory, blood type match) and asked to write one grounded, specific sentence per candidate explaining the recommendation — not from scratch reasoning, but *explaining* a decision already made by the scoring engine
- **Why split scoring from reasoning:** deterministic scoring keeps rankings consistent and testable; Claude is used for what it's best at — natural-language explanation — not for making the ranking decision itself. This also keeps the feature reliable even if the AI's reasoning text is occasionally imperfect, since the ranking itself never depends on it.

---

## 6. External Services

| Service | Purpose | Data sent | Data received |
|---|---|---|---|
| Firebase Authentication | User signup/login/session | email, password (hashed by Firebase) | session/user ID token |
| Cloud Firestore | Store profile, contacts, requests, mock data | profile fields, request text, location | documents/query results |
| Anthropic Claude API | Urgency triage + recommendation reasoning | emergency description, candidate resource stats | urgency classification, reasoning text |
| Browser Geolocation API | Real GPS coordinates | — (browser-only) | latitude/longitude |
| Vercel | Hosting + deployment | Git pushes | live URL |

No external service receives real medical records, payment data, or any data beyond what's explicitly needed for the feature it powers.

---

## 7. Security & Privacy Notes (v1.0 scope)

- The Anthropic API key lives only in Vercel's server-side environment variables — it is never sent to or readable by the browser.
- Firestore Security Rules (configured Day 3) restrict each patient to reading/writing only their own `users/{uid}` document, their own subcollection of `emergencyContacts`, and their own `requests` — never another patient's data.
- Mock hospital/blood bank/donor collections are read-only from the client (writable only via the Firebase Console during setup).
- No real patient medical records, payment info, or insurance data are collected — consistent with PRD Section 5.2 (Out of Scope).

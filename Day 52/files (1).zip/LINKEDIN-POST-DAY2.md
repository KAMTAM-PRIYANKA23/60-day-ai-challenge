Day 2 of my 10-day AI capstone for the AB Talks 60-Day Claude AI Challenge: zero lines of code written today — and that was the point.

I'm building LifeLink, an AI-powered emergency healthcare coordination platform. A patient describes what's happening, Claude AI classifies the urgency, and then ranks the nearest hospitals, blood banks, and donors by distance, availability, and compatibility — with a plain-English reason for every recommendation.

Yesterday I scoped the product. Today I designed the system:

→ Full architecture: how the frontend, database, and Claude API actually talk to each other
→ Complete database schema, checked line-by-line against every user story
→ Every API endpoint specified — request, response, validation, error handling — before writing a single route
→ Every screen wireframed, with a reason for existing traced back to the requirements
→ The exact AI prompts I'll use for urgency triage and recommendation reasoning, drafted and ready

The biggest lesson so far: an hour spent designing the data model before touching code saves many hours of rework later. "Measure twice, cut once" applies just as much to software as carpentry.

Tomorrow: real project setup — Firebase, Next.js, and the first live deployment.

10 days. 1 problem. 1 focused solution. Building in public.

#BuildInPublic #AI #ClaudeAI #ABTalksChallenge #SoftwareEngineering #ProductDevelopment #HealthTech

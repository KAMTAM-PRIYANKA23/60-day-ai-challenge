# LifeLink — Database Design (Cloud Firestore)

**Status:** Approved Day 2 design, companion to `ARCHITECTURE.md`.
Firestore is schemaless — there is no `CREATE TABLE` to run. This document is the enforced *convention* every screen and API route must follow, and the basis for the Firestore Security Rules written on Day 3.

---

## 1. Collections Overview

```
users/{uid}
users/{uid}/emergencyContacts/{contactId}
requests/{requestId}
requests/{requestId}/matches/{matchId}
hospitals/{hospitalId}          (mock, read-only)
bloodBanks/{bankId}             (mock, read-only)
donors/{donorId}                (mock, read-only)
```

Two top-level collections (`users`, `requests`) hold real patient data, each owned by exactly one `uid`. Three top-level collections (`hospitals`, `bloodBanks`, `donors`) hold seeded mock data, shared read-only across all patients.

---

## 2. `users/{uid}`

The document ID **is** the Firebase Auth `uid` — no separate foreign key needed.

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | Display name |
| `email` | string | yes | Mirrors Firebase Auth email, kept for convenience in queries |
| `bloodType` | string | no | One of `O+ O- A+ A- B+ B- AB+ AB-`; may be empty until the patient fills their profile |
| `allergies` | string | no | Free text; empty string if none entered |
| `createdAt` | timestamp | yes | Set once, on first profile creation |
| `updatedAt` | timestamp | yes | Set on every profile edit |

**Validation:** `bloodType`, if present, must be one of the 8 valid values — enforced client-side in the profile form and again in Firestore Security Rules.

### Subcollection: `users/{uid}/emergencyContacts/{contactId}`

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | Contact's name |
| `phone` | string | yes | Free text (not strictly validated as a phone format in v1.0) |
| `relation` | string | yes | e.g. "Spouse", "Parent", "Sibling" |
| `createdAt` | timestamp | yes | |

A subcollection (not an array field on `users`) is used because contacts are added/removed independently and a subcollection gives each contact its own document ID for clean deletion, without rewriting the whole user document.

---

## 3. `requests/{requestId}`

| Field | Type | Required | Notes |
|---|---|---|---|
| `uid` | string | yes | Owner's Firebase Auth uid — used by Security Rules to restrict access |
| `description` | string | yes | Patient's free-text emergency description |
| `latitude` | number | no | Present if GPS permission was granted |
| `longitude` | number | no | Present if GPS permission was granted |
| `manualLocation` | string | no | Present only if GPS was denied — free-text location |
| `urgency` | string | no until triaged | One of `Critical \| High \| Medium \| Low`; absent while status = `Submitted` |
| `urgencyReason` | string | no until triaged | One-sentence AI rationale |
| `status` | string | yes | One of `Submitted \| Triaged \| Matched \| Matching \| HospitalNotified \| AmbulanceDispatched \| Failed` (PRD Section 7.6 simplifies the last three to the visible tracker stages) |
| `createdAt` | timestamp | yes | Set on creation, used to sort History |

**Constraint:** exactly one of (`latitude` + `longitude`) or `manualLocation` must be present — enforced client-side by the Raise Emergency form (FR-6, FR-7).

### Subcollection: `requests/{requestId}/matches/{matchId}`

Written once, by `/api/match`, after scoring completes. Never edited afterward — a request's results are a permanent record, matching PRD FR-17 ("Users can open a past request to review its recommendations").

| Field | Type | Required | Notes |
|---|---|---|---|
| `resourceType` | string | yes | One of `hospital \| bloodBank \| donor` |
| `resourceId` | string | yes | Document ID in the corresponding mock collection |
| `resourceName` | string | yes | Denormalized copy of the name, so History/Results never needs a second read |
| `rank` | number | yes | 1 = top recommendation within its `resourceType` |
| `distanceKm` | number | yes | Computed via Haversine at match time |
| `reason` | string | yes | AI-generated one-sentence explanation |

A subcollection (rather than an array field on `requests`) is used here — even though it's write-once — because it keeps the parent `requests` document small and lets the Results page fetch matches independently of the request's core fields.

---

## 4. Mock Data Collections (seeded once, read-only from the client)

### `hospitals/{hospitalId}`

| Field | Type | Notes |
|---|---|---|
| `name` | string | Realistic hospital name |
| `latitude` | number | |
| `longitude` | number | |
| `bedsAvailable` | number | Used in scoring (PRD FR-11) |
| `specialties` | array\<string\> | e.g. `["Cardiology", "Trauma"]` — descriptive only in v1.0, not used in scoring |

### `bloodBanks/{bankId}`

| Field | Type | Notes |
|---|---|---|
| `name` | string | |
| `latitude` | number | |
| `longitude` | number | |
| `inventory` | map\<string, number\> | e.g. `{ "O+": 12, "A-": 3 }` — one entry per blood type in stock |

### `donors/{donorId}`

| Field | Type | Notes |
|---|---|---|
| `name` | string | |
| `bloodType` | string | One of the 8 valid types |
| `latitude` | number | |
| `longitude` | number | |
| `isAvailable` | boolean | Filtered on directly — unavailable donors are excluded before scoring |

**Day 2 action item:** finalize the actual seed list (6–8 hospitals, 3–4 blood banks, 8–10 donors) using real-ish coordinates in your own city — tracked separately in `design/mock-data.md`, to be entered into Firestore manually on Day 3.

---

## 5. Relationships Summary

```mermaid
erDiagram
    USERS ||--o{ EMERGENCY_CONTACTS : has
    USERS ||--o{ REQUESTS : creates
    REQUESTS ||--o{ MATCHES : produces
    MATCHES }o--|| HOSPITALS : references
    MATCHES }o--|| BLOOD_BANKS : references
    MATCHES }o--|| DONORS : references
```

`MATCHES.resourceId` is a loose reference (not a Firestore-enforced foreign key — Firestore has none) to whichever mock collection matches `resourceType`. The application code, not the database, is responsible for keeping this consistent, since mock data never changes after seeding.

---

## 6. Schema Validated Against PRD User Stories

| PRD Requirement | Satisfied by |
|---|---|
| FR-1, FR-2 (signup/login/session) | Firebase Auth — no Firestore field needed |
| FR-3 (view/edit profile) | `users/{uid}` |
| FR-4 (manage emergency contacts) | `users/{uid}/emergencyContacts/{contactId}` |
| FR-5 (submit description) | `requests/{requestId}.description` |
| FR-6, FR-7 (GPS or manual location) | `requests/{requestId}.latitude/longitude` or `.manualLocation` |
| FR-8 (timestamp every request) | `requests/{requestId}.createdAt` |
| FR-9 (urgency classification) | `requests/{requestId}.urgency`, `.urgencyReason` |
| FR-10, FR-11 (distance + ranking) | `requests/{requestId}/matches/*.distanceKm`, `.rank` |
| FR-12 (reasoning per resource) | `requests/{requestId}/matches/*.reason` |
| FR-13, FR-14 (results dashboard) | `requests/{requestId}` + its `matches` subcollection |
| FR-15 (status tracker) | `requests/{requestId}.status` |
| FR-16, FR-17 (history + reopen past request) | Query `requests` where `uid == currentUser`, ordered by `createdAt desc`; open one to re-read its `matches` |

Every functional requirement in the PRD maps to a concrete field. No PRD requirement is unaddressed, and no field exists that isn't required by some PRD requirement — the schema carries no speculative or "just in case" fields.

---

## 7. Firestore Security Rules (to implement Day 3)

Documented here for planning; written into the Firebase Console on Day 3.

```
match /users/{uid} {
  allow read, write: if request.auth.uid == uid;
  match /emergencyContacts/{contactId} {
    allow read, write: if request.auth.uid == uid;
  }
}

match /requests/{requestId} {
  allow read, write: if request.auth.uid == resource.data.uid
                      || (request.method == 'create' && request.auth.uid == request.resource.data.uid);
  match /matches/{matchId} {
    allow read: if request.auth.uid == get(/databases/$(database)/documents/requests/$(requestId)).data.uid;
    allow write: if false; // written only by the trusted /api/match server route via Admin SDK
  }
}

match /hospitals/{id} { allow read: if true; allow write: if false; }
match /bloodBanks/{id} { allow read: if true; allow write: if false; }
match /donors/{id} { allow read: if true; allow write: if false; }
```

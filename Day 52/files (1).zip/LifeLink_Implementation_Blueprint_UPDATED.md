# LifeLink — Implementation Blueprint (Days 2–10)

**This document is the single source of truth for building LifeLink v1.0.**
Every remaining day of this capstone begins as a *fresh AI conversation*. Paste the relevant day's section (or the whole file) into that conversation so the assistant has full context and does not re-plan or redesign anything already decided here.

---

## 0. Locked Project Foundation (do not re-litigate)

- **Product**: LifeLink — AI-powered emergency healthcare coordination web app
- **Primary user**: Patient / family member (only role with a real login)
- **Supporting stakeholders**: Hospitals, blood banks, donors, ambulances — **mock data only**, no login
- **Core loop**: Patient describes emergency (text) → AI assigns urgency → AI ranks nearby mock resources by distance + availability + compatibility → results dashboard with reasoning → simulated status tracker → saved to history
- **Time budget**: 1–2 hours/day, 9 remaining days
- **Constraint**: Free-tier tools only, no paid services
- **Full feature scope**: see the PRD (`LifeLink_PRD.docx`), Section 5

### Locked Tech Stack (decided today, Day 1, as part of planning — no code written yet)

| Layer | Choice | Why |
|---|---|---|
| Framework | **Next.js (React, App Router)** | One framework for frontend + backend API routes; simplest path from code to deployed app for someone with "some coding experience" |
| Styling | **Tailwind CSS** | Fast to build responsive UI without writing custom CSS from scratch |
| Auth + Database | **Firebase** (Firestore + built-in Auth) | Free tier, real authentication out of the box, a real relational database for profile/history/mock data — no server to manage |
| AI | **Anthropic Claude API** (`claude-sonnet-4-6` or latest available at build time) | Powers urgency triage + recommendation reasoning; called only from server-side Next.js API routes so the API key is never exposed to the browser |
| Location | **Browser Geolocation API** + Haversine distance formula | Real GPS, zero cost, no external maps API needed since map view is out of scope |
| Hosting | **Vercel (free tier)** | Native Next.js support, one-command deploy, generous free tier |
| Version control | **GitHub** | Required for Vercel deployment; also your project portfolio artifact |

> If any of these tools are unfamiliar, Day 2 and Day 3 will explain account creation and setup step by step. Nothing here requires payment.

### High-Level Architecture

```
Browser (Next.js frontend, Tailwind, responsive)
   │
   ├── Firebase Auth (signup/login/session)
   ├── Firebase Firestore (profile, contacts, requests, mock hospitals/blood banks/donors)
   ├── Browser Geolocation API (patient's lat/long)
   │
   └── Next.js API Routes (server-side)
          ├── /api/triage   → calls Claude API → returns urgency level
          └── /api/match    → reads mock data from Firebase, computes distance,
                               calls Claude API for ranking/reasoning, returns
                               ranked hospitals/blood banks/donors
```

### Core Data Model (finalized in detail on Day 2, previewed here)

- `users/{uid}` (name, email, bloodType, allergies)
- `users/{uid}/emergencyContacts/{contactId}` (name, phone, relation)
- `requests/{requestId}` (uid, description, latitude, longitude, urgency, urgencyReason, status, createdAt)
- `requests/{requestId}/matches/{matchId}` (resourceType, resourceId, rank, reason)
- `hospitals/{hospitalId}` (name, latitude, longitude, bedsAvailable, specialties) — mock, read-only
- `bloodBanks/{bankId}` (name, latitude, longitude, inventory) — mock, read-only
- `donors/{donorId}` (name, bloodType, latitude, longitude, isAvailable) — mock, read-only

---

## How to Use This Blueprint Each Day

1. Start a new conversation with your AI assistant.
2. Paste that day's full section below.
3. Say: *"Continue LifeLink from here — I've completed everything up to this point."*
4. Attach/mention any files or screenshots noted in "Handoff notes" from the previous day.
5. Work through the day's step-by-step plan. Do not add features not listed — if something feels tempting, note it under "Future Roadmap" in the PRD instead.
6. Complete the End-of-Day Checklist before stopping.

---

## Day 2 — Design & Architecture

### 🎯 Objective
Turn the PRD into a concrete technical design: finalized database schema, screen-by-screen wireframe plan, and API contract — so that Day 3 onward is pure execution, not decision-making.

### 📖 What I'll learn
How to translate product requirements into a database schema and a screen map before writing any code — the "measure twice, cut once" step most beginners skip.

### 🛠 Features to build
None yet — this is a design-only day. No code is written today.

### 📝 Step-by-step implementation plan
1. Review the Locked Tech Stack and Core Data Model above; confirm you understand each collection's purpose.
2. Finalize the Firestore schema for all collections listed above (fields, types, subcollections). Document it in `schema.md` (to be created directly in Firebase Console on Day 3 — Firestore is schemaless, so this is a documented convention, not an enforced SQL schema).
3. List every screen the app needs: Login, Signup, Profile, Raise Emergency, Results/Recommendations, Status Tracker, Request History, Request Detail. For each, note what data it reads/writes.
4. Sketch (on paper or in a simple diagram) the navigation flow between these screens, matching the Core User Flow in the PRD Section 6.
5. Define the exact request/response shape for the two API routes:
   - `POST /api/triage` — input: `{ description }` → output: `{ urgency: "Critical"|"High"|"Medium"|"Low", rationale: string }`
   - `POST /api/match` — input: `{ description, urgency, latitude, longitude }` → output: `{ hospitals: [...], bloodBanks: [...], donors: [...] }`, each item including a `reason` string
5. Draft the exact AI prompt template for triage (persona + instructions + the patient's description + required output format). Draft a second prompt template for generating the "why recommended" reasoning text.
6. Decide the mock data set: pick a real city/region (your own, since we're using real GPS) and list 6–8 mock hospitals, 3–4 mock blood banks, and 8–10 mock donors with realistic-sounding names and coordinates spread within ~15km of a central point.

### 📂 Files and folders to create or modify
- `/design/schema.md` — the finalized Firestore collection/field definitions
- `/design/screens.md` — screen list + navigation flow
- `/design/api-contracts.md` — request/response shapes for `/api/triage` and `/api/match`
- `/design/prompts.md` — the two AI prompt templates
- `/design/mock-data.md` — the drafted mock hospitals/blood banks/donors list

### 🔗 APIs, libraries, services, or tools to integrate
None yet — planning only. (Firebase and Anthropic accounts can be created today if you want a head start, but no integration work happens until Day 3.)

### 🧪 Testing tasks
- Sanity-check the schema: does every screen from Section 3 have the data it needs from these 7 tables? Walk through the Core User Flow (PRD Section 6) step by step against your schema and confirm nothing is missing.

### 🐞 Common issues and debugging tips
- If you're unsure whether a field belongs in `users/{uid}` or `requests`, ask: "does this change per emergency, or is it stable about the person?" Stable → `users/{uid}`. Changes → `requests`.
- Don't over-normalize the mock data — a single `inventory` map field on each `bloodBanks` document (e.g. `{"O+": 12, "A-": 3}`) is simpler than a separate collection for v1.0.

### ✅ End-of-day checklist
- [ ] `schema.md` written and reviewed
- [ ] Screen list + flow diagram complete
- [ ] Both API contracts defined
- [ ] Both AI prompt templates drafted
- [ ] Mock data list of hospitals/blood banks/donors drafted with real-ish coordinates

### 📸 Expected project state and screenshots to capture
No app exists yet — capture a screenshot or photo of your schema/flow sketch for your own records (optional, not required for grading).

### ➡️ Handoff notes for the next day
Bring `schema.md`, `api-contracts.md`, `prompts.md`, and `mock-data.md` into Day 3. Day 3 will use `schema.md` as the reference while creating collections directly in Firebase Console.

---

## Day 3 — Project Setup & First Deployment

### 🎯 Objective
Get a bare-bones version of LifeLink scaffolded, connected to Firebase, and deployed live on Vercel — before any real feature is built. Deploying early avoids a scramble on Day 10.

### 📖 What I'll learn
How a modern web app's pieces connect: local code → GitHub → Vercel → live URL, and how environment variables keep secrets (API keys) safe.

### 🛠 Features to build
- A working, deployed "shell" app: homepage loads, connects to Firebase, shows a placeholder message — nothing patient-facing yet.

### 📝 Step-by-step implementation plan
1. **Accounts** (guided step-by-step if needed): create free accounts on GitHub, Vercel, Firebase, and the Anthropic Console (for an API key).
2. Create a new Firebase project (enable Firestore in Native mode). Using `schema.md` from Day 2 as a reference, create the top-level collections (`users`, `requests`, `hospitals`, `bloodBanks`, `donors`) in the Firestore Console.
3. Enable Firebase Auth (email/password provider — it's on by default).
4. Insert the Day 2 mock data (hospitals, blood banks, donors) directly into their collections via the Firestore Console's "Add document" UI.
5. Scaffold a new Next.js app locally (`create-next-app`, App Router, Tailwind enabled at creation).
6. Install the Firebase client library and the Anthropic SDK.
7. Create a `.env.local` file with your Firebase Web App config values (`apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`) plus the Anthropic API key. Confirm `.env.local` is in `.gitignore` (never commit secrets).
8. Build a single placeholder homepage that fetches the count of documents in the `hospitals` collection and displays "Connected to Firebase ✅" to prove the connection works.
9. Push the project to a new GitHub repository.
10. Connect the GitHub repo to Vercel, add the same environment variables in Vercel's project settings, and deploy.
11. Visit the live Vercel URL and confirm the placeholder page works in production, not just locally.

### 📂 Files and folders to create or modify
- `/app/page.js` (or `.tsx`) — placeholder homepage
- `/lib/firebaseClient.js` — Firebase client setup
- `.env.local` — local secrets (not committed)
- `.gitignore` — confirm `.env.local` and `node_modules` are excluded
- `README.md` — start documenting setup steps as you go (useful for Day 10)

### 🔗 APIs, libraries, services, or tools to integrate
- Firebase JS SDK (`firebase`)
- Anthropic SDK (`@anthropic-ai/sdk`) — installed now, first used on Day 6
- Vercel + GitHub for CI/deployment

### 🧪 Testing tasks
- Confirm the local dev server (`npm run dev`) shows "Connected to Firebase ✅"
- Confirm the same message appears on the live Vercel URL
- Confirm no secrets appear in the GitHub repo (check the committed files for `.env.local`)

### 🐞 Common issues and debugging tips
- **"Firebase: Error (auth/invalid-api-key)"**: double-check you copied the Web App config values (public by design) from Project Settings, not a server-only service account key.
- **Env vars work locally but not on Vercel**: Vercel needs its own copy of each environment variable added in Project Settings → Environment Variables, then a redeploy.
- **Tailwind classes not applying**: confirm `tailwind.config.js` `content` paths include your `app/` directory.

### ✅ End-of-day checklist
- [ ] Firebase project created with all collections + mock data inserted
- [ ] Next.js app scaffolded locally with Tailwind
- [ ] Firebase connection verified locally
- [ ] Code pushed to GitHub
- [ ] App deployed on Vercel with working environment variables
- [ ] Live URL confirmed working

### 📸 Expected project state and screenshots to capture
- Screenshot of the live Vercel URL showing "Connected to Firebase ✅"
- Screenshot of the Firestore Console showing mock data populated

### ➡️ Handoff notes for the next day
You now have: a live URL, a working database with mock data, and a deployment pipeline. Bring the live URL and confirm the repo is accessible. Day 4 starts building real, patient-facing screens on top of this shell.

---

## Day 4 — Authentication & Patient Profile

### 🎯 Objective
Replace the placeholder homepage with real signup/login and a working patient profile screen (blood type, allergies, emergency contacts).

### 📖 What I'll learn
How to wire up real user authentication and connect a form to a database table (create, read, update).

### 🛠 Features to build
- Signup page, Login page, logout
- Protected profile page (only visible when logged in)
- Profile form: name, blood type dropdown, allergies text field
- Emergency contacts: add / edit / delete list

### 📝 Step-by-step implementation plan
1. Build `/app/signup/page.js` with a form (email, password) calling Firebase Auth `createUserWithEmailAndPassword`.
2. Build `/app/login/page.js` with a form calling Firebase Auth `signInWithEmailAndPassword`.
3. Add a simple auth check (Firebase `onAuthStateChanged` listener) that redirects unauthenticated users away from protected pages.
4. Build `/app/profile/page.js`: on load, fetch the current user's document from `users/{uid}` (create it if it doesn't exist yet); render a form to edit name, blood type (dropdown: O+, O-, A+, A-, B+, B-, AB+, AB-), allergies.
5. Save profile edits back to Firestore (`setDoc` on `users/{uid}`) on submit.
6. Build the emergency contacts section on the same page: list existing contacts from `users/{uid}/emergencyContacts`, a small form to add a new one (name, phone, relation), and a delete button per contact.
7. Add a simple top navigation bar with Logout, visible once logged in.
8. Style all of the above with Tailwind for mobile-first responsiveness (test at a narrow browser width).

### 📂 Files and folders to create or modify
- `/app/signup/page.js`
- `/app/login/page.js`
- `/app/profile/page.js`
- `/lib/auth.js` — helper functions for session/auth checks
- `/components/ContactForm.js`
- `/components/ContactList.js`

### 🔗 APIs, libraries, services, or tools to integrate
- Firebase Auth (`createUserWithEmailAndPassword`, `signInWithEmailAndPassword`, `signOut`, `onAuthStateChanged`)
- Firestore calls (`setDoc`, `updateDoc`, `deleteDoc`, `getDoc`/`getDocs`) on `users/{uid}` and `users/{uid}/emergencyContacts`

### 🧪 Testing tasks
- Sign up with a new test account; confirm a `users/{uid}` document appears in Firestore
- Log out, log back in, confirm the profile persists
- Add 2–3 emergency contacts; refresh the page and confirm they're still there
- Delete a contact and confirm it's removed
- Test on a narrow (mobile-width) browser window

### 🐞 Common issues and debugging tips
- **Profile document missing after signup**: Firebase Auth creates a user, but you must separately create the matching `users/{uid}` document explicitly in your signup code — Firestore has no automatic trigger for this in v1.0's simple setup.
- **Protected page flashes before redirecting**: show a loading state while the session check is in progress instead of rendering the page immediately.
- **Blood type dropdown not saving**: confirm the `<select>` value is included in your form submit handler's state.

### ✅ End-of-day checklist
- [ ] Signup and login working end-to-end
- [ ] Logout working
- [ ] Profile page loads and saves blood type + allergies
- [ ] Emergency contacts can be added and deleted
- [ ] Confirmed working on mobile-width browser
- [ ] Redeployed to Vercel and re-tested on the live URL

### 📸 Expected project state and screenshots to capture
- Screenshot of signup/login screen
- Screenshot of the filled-in profile page with 2+ emergency contacts

### ➡️ Handoff notes for the next day
Auth and profile are live. Bring a logged-in test account (email/password) into Day 5 — you'll use it immediately to test the emergency request form.

---

## Day 5 — Emergency Request Form & Geolocation

### 🎯 Objective
Build the "Raise Emergency" screen: a text description field plus real GPS location capture, saving a new request to the database (AI triage comes next, on Day 6).

### 📖 What I'll learn
How to use the browser's Geolocation API, handle permission prompts and denials gracefully, and calculate real-world distance between two coordinates (Haversine formula).

### 🛠 Features to build
- "Raise Emergency" form (text description)
- GPS location capture with permission handling
- Manual location fallback (if permission denied)
- Save request (description + location) as a new `requests` document with `status: "Submitted"` — `urgency` stays unset until Day 6's triage step populates it

### 📝 Step-by-step implementation plan
1. Build `/app/emergency/page.js` with a large, simple textarea: "Describe what's happening."
2. On page load, call `navigator.geolocation.getCurrentPosition()` to request permission and capture latitude/longitude; store in component state.
3. Handle the permission-denied case: show a manual text input where the user can type a location description instead (store as text if GPS isn't available — full manual-to-coordinates conversion is not required for v1.0; a text note is sufficient fallback).
4. Add a visible, honest status indicator: "Location found" / "Location unavailable — please describe your area."
5. On submit, create a new document in `requests` (description, latitude, longitude, status = "Submitted", createdAt = now) and capture the new document's ID.
6. Redirect to a (placeholder for now) `/app/results/[id]/page.js` route using that request ID — this page will be built out fully on Days 6–7.
7. Write a small utility function implementing the Haversine formula (distance in km between two lat/long points) — this will be used on Day 7 for ranking.
8. Add the required disclaimer text near the form: "LifeLink is a demonstration tool. In a real emergency, always contact local emergency services directly."

### 📂 Files and folders to create or modify
- `/app/emergency/page.js`
- `/app/results/[id]/page.js` (placeholder shell only today)
- `/lib/geolocation.js`
- `/lib/distance.js` — Haversine formula utility

### 🔗 APIs, libraries, services, or tools to integrate
- Browser Geolocation API (`navigator.geolocation`)
- Firestore `addDoc`/`setDoc` on the `requests` collection

### 🧪 Testing tasks
- Submit a request with location permission granted; confirm lat/long saved correctly in the Firestore document
- Deny location permission (browser setting) and confirm the manual fallback appears and the form still submits
- Confirm the new request document appears in Firestore with status "Submitted"
- Test on an actual mobile device if possible (GPS behaves differently than desktop browsers)

### 🐞 Common issues and debugging tips
- **Geolocation only works on HTTPS** (or localhost) — this will work automatically once deployed on Vercel, but note it if testing tricks on local HTTP.
- **Permission prompt not appearing on repeat visits**: browsers remember the choice — test denial in a fresh incognito window.
- **Haversine formula giving wrong distances**: make sure latitude/longitude are in radians before applying the trig functions, and both points use the same order (lat, long) — a common transposition bug.

### ✅ End-of-day checklist
- [ ] Emergency request form built and styled
- [ ] GPS capture working with permission handling
- [ ] Manual fallback working when permission denied
- [ ] Request successfully saved to Firestore with location data
- [ ] Haversine distance utility written and unit-tested with two known coordinates
- [ ] Disclaimer text visible on the form

### 📸 Expected project state and screenshots to capture
- Screenshot of the emergency request form
- Screenshot of the Firestore `requests` collection showing a saved document with lat/long

### ➡️ Handoff notes for the next day
You can now capture a full emergency request with real location. Bring a couple of test request IDs into Day 6 — that's where the AI triage step gets wired in for the first time.

---

## Day 6 — AI Triage Engine

### 🎯 Objective
Wire up the first real AI feature: send the patient's description to Claude and get back a structured urgency classification.

### 📖 What I'll learn
How to call an LLM API from a secure server-side route, how to prompt it for structured, reliable output, and how to handle AI response parsing and failure cases.

### 🛠 Features to build
- `/api/triage` server route
- Urgency badge displayed on the results page
- Loading and error states while waiting on the AI

### 📝 Step-by-step implementation plan
1. Build `/app/api/triage/route.js` (Next.js API route) that accepts `{ description }` in a POST body.
2. Inside the route, call the Anthropic API using the server-side API key (never expose this key to the browser) with the prompt template drafted in `design/prompts.md` on Day 2.
3. Instruct the AI clearly to respond in a strict, parseable format — e.g., ask for a JSON object like `{"urgency": "Critical", "rationale": "..."}` and specify the four allowed urgency values explicitly in the prompt.
4. Parse the AI's response; if parsing fails or the value isn't one of the four allowed levels, default to a safe fallback (e.g., "Medium") and log the issue — never let a malformed AI response crash the page.
5. Update `/app/results/[id]/page.js`: on load, fetch the request, call `/api/triage` with its description, show a loading spinner while waiting, then display the returned urgency as a colored badge (e.g., Critical = red, High = orange, Medium = yellow, Low = green).
6. Update the `requests` document in Firestore with the returned urgency value once received (`updateDoc`).
7. Add a basic error state: if the AI call fails entirely (network/API error), show a friendly message and allow retry — do not leave the user on a blank screen.

### 📂 Files and folders to create or modify
- `/app/api/triage/route.js`
- `/app/results/[id]/page.js` (extended)
- `/components/UrgencyBadge.js`
- `/lib/anthropicClient.js`

### 🔗 APIs, libraries, services, or tools to integrate
- Anthropic Claude API (`@anthropic-ai/sdk`), called only from the server route

### 🧪 Testing tasks
- Submit a clearly critical-sounding description (e.g., "severe chest pain, difficulty breathing") and confirm it returns "Critical" or "High"
- Submit a mild description (e.g., "small cut on finger, minor bleeding") and confirm it returns "Low" or "Medium"
- Temporarily break the API key to confirm the error state displays correctly, then restore it
- Confirm the urgency value is saved back to the `requests` document in Firestore

### 🐞 Common issues and debugging tips
- **AI returns extra text around the JSON**: explicitly instruct in the prompt "respond with ONLY the JSON object, no other text" and still wrap your parsing in a try/catch with a safe fallback.
- **API key exposed in browser network tab**: this means the call is happening client-side by mistake — it must only ever be called from `/app/api/.../route.js` server code.
- **Slow responses feel broken**: always show a visible loading indicator the moment the request is submitted.

### ✅ End-of-day checklist
- [ ] `/api/triage` route built and working
- [ ] Urgency badge displays correctly on the results page
- [ ] Loading state shown while waiting for AI
- [ ] Error/fallback state tested and working
- [ ] Urgency value persisted to Firestore

### 📸 Expected project state and screenshots to capture
- Screenshot of the results page showing a Critical (red) urgency badge
- Screenshot of the results page showing a Low (green) urgency badge, to show the range works

### ➡️ Handoff notes for the next day
AI triage is live. Bring 2–3 tested request examples (one severe, one mild) into Day 7 — that's where the actual hospital/blood bank/donor recommendations get built on top of the urgency signal.

---

## Day 7 — Mock Data, Recommendation Engine & Results Dashboard

### 🎯 Objective
Build the core "wow" feature: AI + distance-based ranking of mock hospitals, blood banks, and donors, displayed as a full results dashboard with reasoning.

### 📖 What I'll learn
How to combine deterministic logic (distance, blood-type compatibility) with AI reasoning to produce ranked, explainable recommendations — a practical pattern for "AI decision support" features.

### 🛠 Features to build
- `/api/match` server route
- Distance + compatibility + urgency-based ranking logic
- AI-generated "why recommended" reasoning per resource
- Full results dashboard UI: ranked cards for hospitals, blood banks, donors

### 📝 Step-by-step implementation plan
1. Build `/app/api/match/route.js` accepting `{ description, urgency, latitude, longitude }`.
2. Fetch all documents from the `hospitals`, `bloodBanks`, and `donors` collections.
3. For each resource, calculate distance from the patient using the Day 5 Haversine utility.
4. Apply deterministic pre-filtering/scoring logic:
   - Hospitals: score by a mix of distance (closer = better) and `bedsAvailable` (more = better); Critical/High urgency should weight distance more heavily.
   - Blood banks: score by distance and whether their inventory contains a compatible blood type for the patient (if profile blood type is known).
   - Donors: filter to compatible blood type and `isAvailable == true`, then score by distance.
5. Take the top 3–5 scored candidates per category and send them, along with the urgency level and description, to Claude via a second prompt (from `design/prompts.md`) asking it to write a short, specific one-sentence "why recommended" reason for each — this is where the AI reasoning layer adds visible intelligence on top of the math.
6. Return the ranked, AI-annotated list from `/api/match`.
7. Save the results into the `requests/{requestId}/matches` subcollection (resourceType, resourceId, resourceName, rank, distanceKm, reason).
8. Build the results dashboard UI: urgency badge at top, then three sections (Hospitals, Blood Banks, Donors) each showing ranked cards with name, distance, key stat (beds/inventory/blood type), and the AI-written reason.
9. Style with Tailwind: card grid on desktop, stacked single column on mobile.

### 📂 Files and folders to create or modify
- `/app/api/match/route.js`
- `/lib/scoring.js` — deterministic scoring logic
- `/components/ResourceCard.js`
- `/app/results/[id]/page.js` (extended further)

### 🔗 APIs, libraries, services, or tools to integrate
- Anthropic Claude API (second prompt, for reasoning text)
- Firestore (`getDocs` on mock collections, `addDoc` on `requests/{requestId}/matches`)

### 🧪 Testing tasks
- Run a request with a Critical urgency and confirm the closest, highest-bed-availability hospitals rank at the top
- Run a request with a known blood type and confirm blood banks/donors shown are actually compatible
- Confirm each card shows a distinct, sensible AI-written reason (not identical boilerplate for every card)
- Confirm results persist: reload the results page and see the same ranked list without recomputing (read from the `matches` subcollection, not re-calling the AI every time)

### 🐞 Common issues and debugging tips
- **All cards get the same generic reason**: make sure each candidate's specific stats (distance, inventory, availability) are included in the prompt sent to the AI per item, not a shared generic prompt.
- **Recommendations don't feel differentiated from urgency to urgency**: confirm your scoring weights actually change based on the urgency parameter (e.g., Critical should weight distance much more heavily than Low).
- **Blood type compatibility bugs**: O- is the universal donor, AB+ is the universal recipient — double check your compatibility matrix rather than assuming exact-match-only logic.

### ✅ End-of-day checklist
- [ ] `/api/match` route working and returning ranked results
- [ ] Deterministic scoring logic implemented and sane
- [ ] AI-generated reasoning text present and distinct per card
- [ ] Results dashboard UI built and responsive
- [ ] Results persisted to the `matches` subcollection and reloadable without recomputation

### 📸 Expected project state and screenshots to capture
- Screenshot of a full results dashboard: urgency badge + ranked hospital/blood bank/donor cards with reasons

### ➡️ Handoff notes for the next day
The core AI coordination experience is complete end-to-end. Bring a fully completed test request (with visible results) into Day 8 — that's where the status simulation and request history get layered on top.

---

## Day 8 — Status Simulation & Request History

### 🎯 Objective
Add the "wow" status simulation feature and a request history dashboard, making the app feel like a living coordination system with a memory.

### 📖 What I'll learn
How to build a simple time-based state machine in the UI (without needing real-time backend infrastructure) and how to query and display a list of a user's past records.

### 🛠 Features to build
- Status simulation: Matching → Hospital Notified → Ambulance Dispatched
- Request history page listing all past requests
- Request detail view (reopen a past request's results)

### 📝 Step-by-step implementation plan
1. Add a `status` field state machine to the results page: on first load after results are shown, status starts at "Matching."
2. Use `setTimeout`/`setInterval` on the client to automatically progress the status after realistic short delays (e.g., 4–6 seconds each): "Matching" → "Hospital Notified" → "Ambulance Dispatched." Update the `status` field on the `requests/{requestId}` document at each transition.
3. Build a visual status tracker component (e.g., horizontal steps with the current step highlighted) reflecting the current status.
4. Build `/app/history/page.js`: query all `requests` documents for the logged-in user (`where uid == currentUser`), ordered by `createdAt` descending, showing date, urgency badge, and status.
5. Make each history item clickable, linking to `/app/results/[id]/page.js` for that request — reusing the same results page built on Days 6–7, but now reading the saved `matches` subcollection instead of recomputing.
6. Add a simple top navigation link to "History" alongside "Raise Emergency" and "Profile."
7. Handle the empty state gracefully: if a user has no past requests yet, show a friendly message and a button to raise their first one.

### 📂 Files and folders to create or modify
- `/app/history/page.js`
- `/components/StatusTracker.js`
- `/app/results/[id]/page.js` (extended: read-only mode for past requests vs. live mode for a fresh one)

### 🔗 APIs, libraries, services, or tools to integrate
- Firestore `getDoc`/`updateDoc` on `requests/{requestId}`
- Client-side timers (`setTimeout`) — no new external service needed

### 🧪 Testing tasks
- Raise a new request and confirm the status visibly progresses through all three stages without a page reload
- Confirm the final status ("Ambulance Dispatched") persists in the Firestore document
- Visit History and confirm all past test requests appear, most recent first
- Click into a past request and confirm it loads its saved results correctly (not recomputing new ones)
- Test the empty state with a brand-new test account

### 🐞 Common issues and debugging tips
- **Status resets on page reload**: make sure you're reading the current status from Firestore on load, and only starting the timer sequence if the request is genuinely new (e.g., status still "Submitted").
- **Old requests re-trigger the animation**: guard the simulation logic so it only runs once per request, the first time results are viewed, not every time the page is opened.
- **History list slow to load**: make sure you're only fetching needed fields and using an index-friendly query (order by `createdAt`, filter by `uid` — Firestore will prompt you to create a composite index the first time this query runs; just click the link it gives you in the console error).

### ✅ End-of-day checklist
- [ ] Status simulation runs automatically and visibly after a new request
- [ ] Status persists correctly to Firestore
- [ ] History page lists all past requests correctly, most recent first
- [ ] Clicking a history item reopens its saved results
- [ ] Empty state handled gracefully

### 📸 Expected project state and screenshots to capture
- Screenshot of the status tracker mid-progression (e.g., "Hospital Notified" highlighted)
- Screenshot of the request history page with 2+ past requests

### ➡️ Handoff notes for the next day
All core and "wow" features are functionally complete. Day 9 is dedicated entirely to testing, bug-fixing, and responsive/visual polish — no new features should be added unless critical bugs are found.

---

## Day 9 — Testing, Debugging & Responsive Polish

### 🎯 Objective
Harden the full app: fix bugs, handle edge cases, and make sure the experience looks and feels polished on both mobile and desktop before deployment day.

### 📖 What I'll learn
How to systematically test a full application end-to-end like a QA engineer, and how to prioritize fixes under limited time.

### 🛠 Features to build
None — no new features today. This is a stabilization day only.

### 📝 Step-by-step implementation plan
1. Walk through the entire Core User Flow (PRD Section 6) start to finish, on both desktop and a real mobile device/browser, writing down every bug or rough edge you notice.
2. Prioritize the bug list: fix anything that breaks the core flow first, then visual polish, then nice-to-haves.
3. Re-test all edge cases explicitly:
   - Empty/very short emergency description
   - Location permission denied
   - AI API failure (temporarily test with an invalid key, then restore)
   - Logging out mid-flow / session expiration
   - Very long text in description or allergies fields (overflow check)
4. Pass over every screen and check spacing, font sizes, button tap targets on mobile (minimum ~44px tall), and color contrast for the urgency badges.
5. Confirm the emergency disclaimer is visible on both the request form and results page.
6. Clean up any leftover placeholder/debug text (e.g., "Connected to Firebase ✅" if not already removed).
7. Do a final performance pass: confirm pages load in a reasonable time, no obvious console errors in the browser dev tools.
8. Commit and push all fixes; redeploy to Vercel; re-test the live URL, not just localhost.

### 📂 Files and folders to create or modify
- Any files touched by bug fixes — no new files expected today
- `/BUGLOG.md` — optional running list of what you found and fixed, useful context for Day 10 documentation

### 🔗 APIs, libraries, services, or tools to integrate
None new — this day is entirely about hardening existing integrations.

### 🧪 Testing tasks
- Full end-to-end run-through: signup → profile → raise emergency → AI triage → recommendations → status simulation → history — on desktop
- Same full run-through on a mobile browser
- All edge cases listed in step 3 above
- Cross-browser spot check if time allows (e.g., Chrome + one other browser)

### 🐞 Common issues and debugging tips
- **Works on localhost, breaks on Vercel**: almost always missing/mismatched environment variables — recheck Vercel project settings.
- **Layout breaks only on real mobile, not browser dev tools' mobile emulator**: always do at least one pass on an actual phone if possible; emulators aren't perfect.
- **Console shows "Hydration mismatch" errors**: usually caused by rendering something client-only (like geolocation data) during server render — guard with a loading/mounted check.

### ✅ End-of-day checklist
- [ ] Full core flow tested and working on desktop
- [ ] Full core flow tested and working on mobile
- [ ] All edge cases from step 3 tested
- [ ] No visible placeholder/debug content remaining
- [ ] No console errors on key pages
- [ ] Final version redeployed and re-verified on the live Vercel URL

### 📸 Expected project state and screenshots to capture
- Screenshot of the app on mobile width showing the results dashboard, to prove responsiveness
- Screenshot of your bug list showing items marked resolved (optional)

### ➡️ Handoff notes for the next day
The app is stable and polished. Day 10 is documentation, final deployment verification, and pitch/demo preparation — no further feature or bug work is planned unless something critical is found.

---

## Day 10 — Final Deployment, Documentation & Demo Readiness

### 🎯 Objective
Lock in the final deployed v1.0, write project documentation, and prepare a confident live demo using the Pitch Deck.

### 📖 What I'll learn
How to close out a software project professionally: documentation, final release checks, and presenting technical work to a non-technical or mixed audience.

### 🛠 Features to build
None — this day is about finishing, documenting, and presenting, not building.

### 📝 Step-by-step implementation plan
1. Do one final full run-through of the live (not local) Vercel URL, exactly as a judge/viewer would experience it, on both desktop and mobile.
2. Finalize `README.md` in the repository: project name and one-line pitch, problem it solves, tech stack used, how to run it locally, live demo link, and screenshots.
3. Write a 60–90 second demo script: what you'll say while clicking through signup → raise emergency → AI triage → results → status simulation → history. Practice it out loud at least twice.
4. Review the Pitch Deck (`LifeLink_Pitch_Deck.pptx`) generated today (Day 1) and update any placeholder screenshots with real screenshots from your finished app.
5. Double-check the disclaimer is visible in the live app (PRD Section 12).
6. Tag/label this version as v1.0 in your GitHub repo (e.g., a git tag or a note in the README) so there's a clear "this is what I shipped" marker.
7. Prepare answers to likely questions: "What would you build next?" (point to PRD Section 9, Future Roadmap), "What was hardest?", "How does the AI actually decide urgency?"

### 📂 Files and folders to create or modify
- `/README.md` (finalized)
- Pitch deck screenshots updated with real app images

### 🔗 APIs, libraries, services, or tools to integrate
None new — final verification of all existing integrations only.

### 🧪 Testing tasks
- Full live-URL run-through as a first-time user would experience it, with zero prior context
- Confirm the demo script matches exactly what happens on screen — no surprises during a live demo

### 🐞 Common issues and debugging tips
- **Live demo shows different data than local dev**: always demo from the deployed Vercel URL, not localhost, so there are no surprises in front of an audience.
- **Nerves during live demo**: if anything unexpected happens live, have 2–3 screenshots from Day 9 ready as a fallback narrative ("here's what it normally looks like").

### ✅ End-of-day checklist
- [ ] Final live URL tested end-to-end as a first-time user
- [ ] README finalized with live link and screenshots
- [ ] Demo script written and practiced
- [ ] Pitch deck updated with real screenshots
- [ ] v1.0 clearly marked/tagged in the repo

### 📸 Expected project state and screenshots to capture
- Full set of final screenshots: login, profile, raise emergency, results dashboard, status tracker, history — for the README and pitch deck

### ➡️ Handoff notes for the next day
**This is the last day.** Capstone complete: LifeLink v1.0 is deployed, documented, and demo-ready.

---

## Appendix: Definition of "Done" for the Capstone

LifeLink v1.0 is considered complete when all of the following are true:

- [ ] Live, publicly accessible URL works with no local setup required
- [ ] A new user can sign up, build a profile, and raise an emergency request end-to-end
- [ ] AI triage returns a sensible urgency level for varied input descriptions
- [ ] AI-ranked recommendations for hospitals, blood banks, and donors display with reasoning
- [ ] Status simulation runs automatically and visibly
- [ ] Request history is viewable and past requests reload correctly
- [ ] The app is fully usable on both mobile and desktop
- [ ] PRD, this Blueprint, and the Pitch Deck are all finished and consistent with the shipped product

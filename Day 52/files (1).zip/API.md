# LifeLink — API Design

**Status:** Approved Day 2 design. No implementation yet — this defines exactly what Day 6 and Day 7 will build.

---

## 1. What Counts as an "Endpoint" in This Architecture

Per `ARCHITECTURE.md`, most of LifeLink's data operations happen **directly from the browser to Firestore** via the Firebase client SDK — there is no custom endpoint for signup, login, profile edits, contact management, or reading history. Those are documented in Section 3 below for completeness, but they are not REST endpoints.

Only two operations require a custom server-side endpoint, because they need the Anthropic API key, which must never be exposed to the browser:

| Endpoint | Purpose |
|---|---|
| `POST /api/triage` | Classify emergency urgency |
| `POST /api/match` | Rank and explain nearby resources |

---

## 2. Endpoint Specifications

### 2.1 `POST /api/triage`

**Purpose:** Send the patient's emergency description to Claude and receive a structured urgency classification.

**Authentication:** Requires a valid Firebase Auth session. The route verifies the Firebase ID token passed in the `Authorization` header before proceeding.

**Request:**
```json
{
  "description": "string, required, 1-2000 characters"
}
```

**Success Response — 200:**
```json
{
  "urgency": "Critical | High | Medium | Low",
  "rationale": "One-sentence explanation of the classification."
}
```

**Validation:**
- `description` must be a non-empty string, max 2000 characters (reject with 400 otherwise)
- Reject if no valid Firebase Auth token is present (401)

**Error Cases:**

| Case | Status | Response |
|---|---|---|
| Missing/empty `description` | 400 | `{ "error": "description is required" }` |
| No/invalid auth token | 401 | `{ "error": "unauthorized" }` |
| Claude API call fails or times out | 502 | `{ "error": "triage_unavailable", "urgency": "Medium", "rationale": "Automatic classification unavailable — defaulted to Medium. Please seek help immediately if this is a real emergency." }` |
| Claude response fails to parse into a valid urgency value | 200 (fallback, not an error to the client) | Same fallback body as above, `urgency: "Medium"` |

**Note on the fallback strategy:** a triage failure must never block the patient from proceeding — the route always returns a usable urgency value, defaulting to `"Medium"` (a safety-conscious middle ground, consistent with PRD Section 9.1's "err toward caution" principle) rather than surfacing a raw error to someone in a possible emergency.

---

### 2.2 `POST /api/match`

**Purpose:** Score and rank mock hospitals, blood banks, and donors for a given request, and generate AI reasoning for the top candidates.

**Authentication:** Same as `/api/triage` — valid Firebase Auth token required.

**Request:**
```json
{
  "description": "string, required",
  "urgency": "Critical | High | Medium | Low, required",
  "latitude": "number, optional",
  "longitude": "number, optional",
  "bloodType": "string, optional — from the patient's profile, used for compatibility scoring"
}
```

**Success Response — 200:**
```json
{
  "hospitals": [
    {
      "id": "string",
      "name": "string",
      "distanceKm": "number",
      "bedsAvailable": "number",
      "rank": "number",
      "reason": "string"
    }
  ],
  "bloodBanks": [
    {
      "id": "string",
      "name": "string",
      "distanceKm": "number",
      "matchingUnits": "number",
      "rank": "number",
      "reason": "string"
    }
  ],
  "donors": [
    {
      "id": "string",
      "name": "string",
      "distanceKm": "number",
      "bloodType": "string",
      "rank": "number",
      "reason": "string"
    }
  ]
}
```

**Validation:**
- `description` and `urgency` are required; `urgency` must be one of the four valid values
- If neither `latitude`/`longitude` nor a prior manual location context is available, distance-based ranking is skipped and resources are ranked by availability/compatibility only (documented fallback, not an error)

**Error Cases:**

| Case | Status | Response |
|---|---|---|
| Missing `description` or invalid `urgency` | 400 | `{ "error": "description and a valid urgency are required" }` |
| No/invalid auth token | 401 | `{ "error": "unauthorized" }` |
| No mock resources found in Firestore (misconfiguration) | 500 | `{ "error": "no_resources_available" }` |
| Claude reasoning call fails | 200 (degraded, not a hard error) | Same ranked list, with `reason: "Recommended based on proximity and availability."` as a generic fallback per item |

**Note on the degraded fallback:** if Claude's reasoning call fails, the deterministic ranking (computed independently in code, per `ARCHITECTURE.md` Section 5.2) still returns successfully — only the natural-language explanation degrades to a generic sentence. The feature is never fully blocked by an AI outage.

---

## 3. Non-Endpoint Data Operations (Direct Firestore SDK Calls)

Documented here for completeness, since the PRD's user stories require them — these are **not** REST endpoints, they're direct client-to-Firestore calls governed by the Security Rules in `SCHEMA.md` Section 7.

| Operation | PRD Requirement | Firestore Call |
|---|---|---|
| Sign up | FR-1 | `createUserWithEmailAndPassword` (Firebase Auth SDK) |
| Log in | FR-2 | `signInWithEmailAndPassword` |
| Log out | FR-2 | `signOut` |
| Read/write profile | FR-3 | `getDoc` / `setDoc` on `users/{uid}` |
| Add/remove emergency contact | FR-4 | `addDoc` / `deleteDoc` on `users/{uid}/emergencyContacts` |
| Create a request | FR-5–FR-8 | `addDoc` on `requests` |
| Update request status | FR-15 | `updateDoc` on `requests/{id}` (client-side timer-driven, per `ARCHITECTURE.md` Section 4) |
| Read request history | FR-16 | `query(requests, where uid ==, orderBy createdAt desc)` |
| Read a past request's matches | FR-17 | `getDocs` on `requests/{id}/matches` |

---

## 4. Why Only Two Custom Endpoints

This is a deliberate architectural minimalism decision, not an oversight: every operation that doesn't need the Claude API key goes straight from the browser to Firestore, governed by Security Rules instead of custom server code. This means Day 6 and Day 7 are the *only* days that involve writing backend route code — every other implementation day is pure frontend + Firestore SDK work, which fits the 1–2 hr/day budget far better than maintaining a full custom REST API surface.

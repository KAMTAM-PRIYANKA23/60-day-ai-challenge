# LifeLink — UI & User Flow

**Status:** Approved Day 2 design. Low-fidelity wireframes — visual polish happens Day 9, not before.

---

## 1. User Flow Diagram

```mermaid
flowchart TD
    Start([Patient opens app]) --> Auth{Logged in?}
    Auth -- No --> Login[Login Screen]
    Login -- No account --> Signup[Signup Screen]
    Signup --> Home
    Login --> Home
    Auth -- Yes --> Home[Home / Dashboard]

    Home --> Profile[Profile Screen]
    Home --> Emergency[Raise Emergency Screen]
    Home --> History[Request History Screen]

    Profile --> Home

    Emergency --> Results[Results Dashboard]
    Results --> Status[Status Tracker - inline on Results]
    Status --> History

    History --> Detail[Past Request Detail - reuses Results view, read-only]
    Detail --> History
```

**Design principle:** there are exactly 3 destinations from Home (Profile, Raise Emergency, History) — no deeper navigation exists anywhere in v1.0. This is intentional: an emergency tool cannot ask a stressed user to hunt through menus.

---

## 2. Screen List — Every Screen and Why It Exists

| Screen | Exists because... |
|---|---|
| Login | Required for account access (PRD FR-2) |
| Signup | Required for new patients (PRD FR-1) |
| Home / Dashboard | Single hub — the only screen with all 3 primary actions visible |
| Profile | Blood type, allergies, emergency contacts must be viewable/editable (FR-3, FR-4) |
| Raise Emergency | The core action of the entire product (FR-5–FR-8) |
| Results Dashboard | Where urgency + ranked recommendations + status tracker live (FR-9–FR-15) |
| Request History | Past requests list (FR-16) |
| Request Detail (reopened past request) | Reuses the Results Dashboard in read-only mode (FR-17) — not a separate screen design, just a mode |

No screen exists that isn't traceable to a specific PRD functional requirement — there is no settings screen, no admin screen, no onboarding tour, per the approved Out of Scope list.

---

## 3. Low-Fidelity Wireframes

### 3.1 Login / Signup

```
┌─────────────────────────────────┐
│   ❤ LifeLink                    │
│                                  │
│   [ Email____________________ ] │
│   [ Password_________________ ] │
│                                  │
│   [        Log In          ]    │
│                                  │
│   New here? Sign up →           │
└─────────────────────────────────┘
```

### 3.2 Home / Dashboard

```
┌─────────────────────────────────┐
│  ❤ LifeLink            [Logout] │
├─────────────────────────────────┤
│                                  │
│   Hi, [Name]                    │
│                                  │
│  ┌───────────────────────────┐  │
│  │   🚨 Raise Emergency       │  │  <- primary, largest button
│  └───────────────────────────┘  │
│                                  │
│  [ 👤 Profile ]  [ 🕐 History ]  │
│                                  │
└─────────────────────────────────┘
```

### 3.3 Profile

```
┌─────────────────────────────────┐
│  ← Back            Profile      │
├─────────────────────────────────┤
│  Name:  [________________]      │
│  Blood Type: [ O+  ▾ ]           │
│  Allergies: [_________________] │
│                                  │
│  Emergency Contacts              │
│  ┌───────────────────────────┐  │
│  │ Priya (Sister) 98xxxxxxxx │x│  │
│  ├───────────────────────────┤  │
│  │ + Add contact              │  │
│  └───────────────────────────┘  │
│                                  │
│  [        Save Changes      ]   │
└─────────────────────────────────┘
```

### 3.4 Raise Emergency

```
┌─────────────────────────────────┐
│  ← Back        Raise Emergency  │
├─────────────────────────────────┤
│  Describe what's happening:     │
│  ┌───────────────────────────┐  │
│  │                            │ │
│  │                            │ │
│  └───────────────────────────┘  │
│                                  │
│  📍 Location found ✅            │
│  (or) [ Type your area______ ]  │
│                                  │
│  ⚠ This is a demo tool. In a    │
│  real emergency, call local     │
│  emergency services directly.   │
│                                  │
│  [       Submit Request      ]  │
└─────────────────────────────────┘
```

### 3.5 Results Dashboard

```
┌─────────────────────────────────┐
│  ← Back            Results      │
├─────────────────────────────────┤
│   🔴 URGENCY: CRITICAL           │
│   "Rationale from AI here..."   │
├─────────────────────────────────┤
│  Status: ● Matching → ○ Notified │
│          → ○ Dispatched          │
├─────────────────────────────────┤
│  🏥 Hospitals                    │
│  ┌───────────────────────────┐  │
│  │ City General — 2.1km       │ │
│  │ 4 beds available            │ │
│  │ "Closest with capacity"    │ │
│  └───────────────────────────┘  │
│  [ next hospital card... ]       │
├─────────────────────────────────┤
│  🩸 Blood Banks                  │
│  [ cards... ]                    │
├─────────────────────────────────┤
│  🙋 Donors                       │
│  [ cards... ]                    │
└─────────────────────────────────┘
```

### 3.6 Request History

```
┌─────────────────────────────────┐
│  ← Back            History      │
├─────────────────────────────────┤
│  ┌───────────────────────────┐  │
│  │ 🔴 Critical  Jul 26, 2026  │  │
│  │ "severe chest pain..."     │  │
│  └───────────────────────────┘  │
│  ┌───────────────────────────┐  │
│  │ 🟡 Medium   Jul 20, 2026   │  │
│  │ "twisted ankle..."         │  │
│  └───────────────────────────┘  │
│                                  │
│  (empty state if none yet:      │
│   "No requests yet." + button   │
│   to raise the first one)       │
└─────────────────────────────────┘
```

---

## 4. Navigation Summary

- **Top-level nav (always reachable from Home):** Raise Emergency, Profile, History
- **No nav bar on Login/Signup** — those are pre-authentication, dead-end screens by design
- **No nav bar on Results** — deliberately: while viewing critical results, the only actions are "Back" (to History/Home) — nothing should distract from the recommendations
- **Every screen has a single, unambiguous "Back"** — no breadcrumbs, no tabs, no hidden menus, matching the "low cognitive load during an emergency" principle

---

## 5. Responsive Behavior

- **Mobile (< 640px):** single-column stack, resource cards full-width, large tap targets (min 44px height) per PRD NFR-1
- **Desktop (≥ 1024px):** resource cards can lay out 2–3 per row within each category section; form/profile screens stay narrow (max ~600px) and centered rather than stretching edge-to-edge

All wireframes above are drawn mobile-first; desktop is a widened, multi-column variant of the exact same structure — no separate desktop-only screens or flows exist.

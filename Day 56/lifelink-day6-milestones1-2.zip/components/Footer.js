export default function Footer() {
  return (
    <footer className="text-center text-xs text-gray-400 py-6 mt-10 border-t border-gray-200">
      Built with Claude as part of the AB Talks 60-Day Claude AI Challenge.
    </footer>
  );
}

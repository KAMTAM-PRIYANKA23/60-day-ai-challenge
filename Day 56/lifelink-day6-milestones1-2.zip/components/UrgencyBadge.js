export default function UrgencyBadge({ urgency }) {
  const styles = {
    Critical: "bg-red-100 text-red-800 border-red-300",
    High: "bg-orange-100 text-orange-800 border-orange-300",
    Medium: "bg-yellow-100 text-yellow-800 border-yellow-300",
    Low: "bg-green-100 text-green-800 border-green-300",
  };
  const style = styles[urgency] || "bg-gray-100 text-gray-800 border-gray-300";
  return (
    <span
      className={`inline-block px-4 py-1.5 rounded-full border font-bold text-sm ${style}`}
    >
      {urgency ? urgency.toUpperCase() : "..."}
    </span>
  );
}

import { NextResponse } from "next/server";
import { adminAuth } from "@/lib/firebaseAdmin";
import { classifyUrgency } from "@/lib/geminiClient";

// Safe fallback used whenever Gemini fails or returns something unusable —
// the patient must never be blocked by an AI outage (docs/API.md Section 2.1).
const FALLBACK = {
  urgency: "Medium",
  rationale:
    "Automatic classification unavailable — defaulted to Medium. Please seek help immediately if this is a real emergency.",
};

export async function POST(request) {
  // --- Auth check ---
  const authHeader = request.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  try {
    await adminAuth.verifyIdToken(token);
  } catch (err) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  // --- Validation ---
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "description is required" },
      { status: 400 }
    );
  }
  const description = (body?.description || "").trim();
  if (!description || description.length > 2000) {
    return NextResponse.json(
      { error: "description is required" },
      { status: 400 }
    );
  }

  // --- Call Gemini, fall back safely on any failure ---
  try {
    const result = await classifyUrgency(description);
    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    console.error("Triage classification failed:", err);
    return NextResponse.json(FALLBACK, { status: 200 });
  }
}

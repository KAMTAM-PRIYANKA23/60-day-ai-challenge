import "./globals.css";
import { AuthProvider } from "@/lib/AuthContext";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "LifeLink — Emergency Healthcare Coordination",
  description:
    "AI-powered emergency healthcare coordination platform — AB Talks Claude AI Challenge capstone.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 min-h-screen flex flex-col">
        <AuthProvider>
          <NavBar />
          <main className="max-w-3xl mx-auto px-4 py-6 flex-1 w-full">
            {children}
          </main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}

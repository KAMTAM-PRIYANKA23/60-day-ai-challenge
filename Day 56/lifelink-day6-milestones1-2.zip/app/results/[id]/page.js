"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ref, get, update } from "firebase/database";
import { useAuth } from "@/lib/AuthContext";
import { db } from "@/lib/firebaseClient";
import UrgencyBadge from "@/components/UrgencyBadge";

export default function ResultsPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const params = useParams();
  const requestId = params.id;

  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [triaging, setTriaging] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login");
    }
  }, [authLoading, user, router]);

  useEffect(() => {
    if (!user || !requestId) return;

    async function loadAndTriage() {
      setLoading(true);
      setError("");
      const reqRef = ref(db, `users/${user.uid}/requests/${requestId}`);
      const snap = await get(reqRef);

      if (!snap.exists()) {
        setError("Request not found.");
        setLoading(false);
        return;
      }

      const data = snap.val();
      setRequest(data);
      setLoading(false);

      if (!data.urgency) {
        setTriaging(true);
        try {
          const idToken = await user.getIdToken();
          const res = await fetch("/api/triage", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${idToken}`,
            },
            body: JSON.stringify({ description: data.description }),
          });
          const result = await res.json();
          await update(reqRef, {
            urgency: result.urgency,
            urgencyReason: result.rationale,
            status: "Triaged",
          });
          setRequest((prev) => ({
            ...prev,
            urgency: result.urgency,
            urgencyReason: result.rationale,
            status: "Triaged",
          }));
        } catch (err) {
          console.error(err);
          setError(
            "Couldn't classify urgency right now. Please try refreshing."
          );
        } finally {
          setTriaging(false);
        }
      }
    }

    loadAndTriage();
  }, [user, requestId]);

  if (authLoading || !user || loading) {
    return <p className="text-center py-12 text-gray-500">Loading...</p>;
  }

  if (error && !request) {
    return <p className="text-center py-12 text-red-600">{error}</p>;
  }

  return (
    <div className="max-w-lg mx-auto py-8 space-y-6">
      <h1 className="text-2xl font-bold text-[#1E2761]">Results</h1>

      <div className="border border-gray-200 rounded-xl p-4 bg-white space-y-3">
        <p className="text-sm text-gray-500">Your description:</p>
        <p className="text-sm">{request.description}</p>
      </div>

      <div className="border border-gray-200 rounded-xl p-4 bg-white">
        {triaging ? (
          <p className="text-sm text-gray-500">🧠 Analyzing urgency...</p>
        ) : request.urgency ? (
          <div className="space-y-2">
            <UrgencyBadge urgency={request.urgency} />
            <p className="text-sm text-gray-600">{request.urgencyReason}</p>
          </div>
        ) : (
          <p className="text-sm text-red-600">
            {error || "Urgency not available."}
          </p>
        )}
      </div>

      <p className="text-sm text-gray-400 text-center">
        Ranked hospital, blood bank, and donor recommendations arrive Day 7.
      </p>
    </div>
  );
}
